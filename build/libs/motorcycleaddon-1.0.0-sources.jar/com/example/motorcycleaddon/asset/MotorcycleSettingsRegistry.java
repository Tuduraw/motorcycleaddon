package com.example.motorcycleaddon.asset;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

/** Per-vehicle MotorcycleSettings, keyed by the same vehicle Identifier the base mod's own
 * VehicleRegistry uses.
 *
 * Scans data/&lt;namespace&gt;/vehicles/*.json - the exact same files the base mod parses - and picks
 * out only the "motorcycle" object, leaving every other key to the base mod. Reloading on the same
 * resource-reload event means /reload updates both halves together.
 *
 * NOTE: this reads the resource-pack/datapack tree only. Vehicles supplied through the base mod's
 * own external tudursvehiclemod-addons/ folder still load and drive fine - they simply fall back to
 * MotorcycleSettings.DEFAULT, since this listener never sees those files. */
public final class MotorcycleSettingsRegistry implements SimpleSynchronousResourceReloadListener {

	private static final Logger LOGGER = LoggerFactory.getLogger("MotorcycleAddon/Settings");
	private static final String DIRECTORY = "vehicles";
	private static final String SUFFIX = ".json";
	/** The one key inside a vehicle JSON that belongs to this addon. */
	private static final String SETTINGS_KEY = "motorcycle";

	private static Map<class_2960, MotorcycleSettings> loaded = Map.of();

	/** Settings for one vehicle, or DEFAULT if it declared none. Never null. */
	public static MotorcycleSettings get(class_2960 vehicleId) {
		if (vehicleId == null) {
			return MotorcycleSettings.DEFAULT;
		}
		return loaded.getOrDefault(vehicleId, MotorcycleSettings.DEFAULT);
	}

	@Override
	public class_2960 getFabricId() {
		return class_2960.method_60655("motorcycleaddon", "motorcycle_settings");
	}

	@Override
	public void method_14491(class_3300 manager) {
		Map<class_2960, MotorcycleSettings> result = new HashMap<>();

		for (Map.Entry<class_2960, class_3298> entry :
				manager.method_14488(DIRECTORY, id -> id.method_12832().endsWith(SUFFIX)).entrySet()) {

			class_2960 fileId = entry.getKey();
			String path = fileId.method_12832();
			// Same id derivation the base mod's own listener uses, so the keys line up exactly.
			class_2960 vehicleId = class_2960.method_60655(
					fileId.method_12836(),
					path.substring(DIRECTORY.length() + 1, path.length() - SUFFIX.length())
			);

			try (Reader reader = entry.getValue().method_43039()) {
				JsonElement json = JsonParser.parseReader(reader);
				if (!json.isJsonObject()) {
					continue;
				}
				JsonObject obj = json.getAsJsonObject();
				if (!obj.has(SETTINGS_KEY)) {
					continue;
				}
				MotorcycleSettings.CODEC.parse(JsonOps.INSTANCE, obj.get(SETTINGS_KEY))
						.resultOrPartial(error ->
								LOGGER.error("Failed to parse motorcycle settings for '{}': {}", vehicleId, error))
						.ifPresent(settings -> result.put(vehicleId, settings));
			} catch (Exception e) {
				LOGGER.error("Failed to read motorcycle settings for {}", vehicleId, e);
			}
		}

		loaded = Map.copyOf(result);
		LOGGER.info("Loaded motorcycle settings for {} vehicle(s)", loaded.size());
	}
}
