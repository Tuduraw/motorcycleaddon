package com.example.motorcycleaddon.network;

import com.example.motorcycleaddon.MotorcycleAddon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server: whether the rider is currently holding the acrobatics key.
 *
 * A held state rather than a toggle, so the wheelie lasts exactly as long as the key is down. Sent
 * only when the value actually changes (see MotorcycleAddonClient), not every tick. */
public record AcrobaticsPayload(boolean held) implements class_8710 {

	public static final class_8710.class_9154<AcrobaticsPayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(MotorcycleAddon.MOD_ID, "acrobatics"));

	public static final class_9139<class_9129, AcrobaticsPayload> CODEC = class_9139.method_56434(
			class_9135.field_48547, AcrobaticsPayload::held,
			AcrobaticsPayload::new
	);

	@Override
	public class_8710.class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
