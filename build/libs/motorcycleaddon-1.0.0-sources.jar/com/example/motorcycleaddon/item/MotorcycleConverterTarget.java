package com.example.motorcycleaddon.item;

import com.example.motorcycleaddon.MotorcycleAddon;
import com.example.tudursvehiclemod.item.VehicleConverterTarget;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

/** Opts the motorcycle into the base mod's own tiered base item -> spawner item converter, and into
 * packing a placed motorcycle back up into a spawner item.
 *
 * Registering this is entirely optional. An addon that wants a costlier or otherwise independent
 * way of obtaining its vehicles simply never registers a target, and the converter then has no
 * knowledge of it at all. */
public class MotorcycleConverterTarget implements VehicleConverterTarget {

	/** Must match the entity type registered in MotorcycleAddon, and the "entity_type" every
	 * motorcycle vehicle JSON names - this is what ties a placed vehicle back to this target. */
	@Override
	public class_2960 entityTypeId() {
		return class_2960.method_60655(MotorcycleAddon.MOD_ID, "motorcycle");
	}

	@Override
	public String translationKey() {
		return "item.motorcycleaddon.category.motorcycle";
	}

	/** This addon's own namespace, so it can never collide with the base mod's own target ids. */
	@Override
	public class_2960 id() {
		return class_2960.method_60655(MotorcycleAddon.MOD_ID, "motorcycle");
	}

	@Override
	public class_1792[] tieredSpawnerItems() {
		return MotorcycleItems.MOTORCYCLE_SPAWNERS;
	}
}
