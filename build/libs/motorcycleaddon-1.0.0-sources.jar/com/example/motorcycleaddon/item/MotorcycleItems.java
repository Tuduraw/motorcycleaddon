package com.example.motorcycleaddon.item;

import com.example.motorcycleaddon.MotorcycleAddon;
import com.example.tudursvehiclemod.item.TieredVehicleSpawnerItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** This addon's own items.
 *
 * These are the base mod's own TieredVehicleSpawnerItem, not a bespoke item: that class is typed
 * against VehicleConverterTarget, so an addon's own target works in it directly. The payoff is the
 * base mod's own vehicle SELECTION screen - right-clicking a tier-3 spawner lists every registered
 * motorcycle of tier 3 or below, searchable and paged, with no screen or networking code here.
 *
 * The base mod still creates nothing on an addon's behalf: the items are registered here, under this
 * addon's own namespace, and the resulting array is what gets handed to the converter registry. */
public class MotorcycleItems {

	/** [tier - 1]. Handed to the base mod's converter through MotorcycleConverterTarget. */
	public static final class_1792[] MOTORCYCLE_SPAWNERS = new class_1792[5];

	/** The single converter target these items are scoped to - also what the selection screen filters
	 * by, so only motorcycles appear in it. */
	public static final MotorcycleConverterTarget TARGET = new MotorcycleConverterTarget();

	public static void register() {
		for (int tier = 1; tier <= 5; tier++) {
			String path = "motorcycle_spawner_t" + tier;
			class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MotorcycleAddon.MOD_ID, path));
			class_1792 item = new TieredVehicleSpawnerItem(
					new class_1792.class_1793().method_63686(key).method_7889(1), TARGET, tier);
			MOTORCYCLE_SPAWNERS[tier - 1] = class_2378.method_39197(class_7923.field_41178, key, item);
		}

		class_5321<class_1761> groupKey =
				class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(MotorcycleAddon.MOD_ID, "motorcycles"));
		class_2378.method_39197(class_7923.field_44687, groupKey, FabricItemGroup.builder()
				.method_47320(() -> new class_1799(MOTORCYCLE_SPAWNERS[0]))
				.method_47321(class_2561.method_43471("itemGroup.motorcycleaddon.motorcycles"))
				.method_47324());

		ItemGroupEvents.modifyEntriesEvent(groupKey).register(entries -> {
			for (class_1792 item : MOTORCYCLE_SPAWNERS) {
				entries.method_45421(item);
			}
		});
	}
}
